# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: signup-carousel.spec.ts >> Signup flow – OAuth integration >> error banner clears when the user retries sign-up after a failure
- Location: e2e/signup-carousel.spec.ts:252:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('signup-continue-button')
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByTestId('signup-continue-button')

```

# Page snapshot

```yaml
- generic [ref=e10]:
  - generic [ref=e11]:
    - generic [ref=e13] [cursor=pointer]: 
    - generic [ref=e14]: Create account
  - generic [ref=e16]:
    - generic [ref=e18]: PB
    - generic [ref=e19]: Welcome to PinnboxIO
  - generic [ref=e21]:
    - generic [ref=e23]:
      - img [ref=e25]
      - generic [ref=e40]: All your inboxes, one place
      - generic [ref=e41]: Connect Gmail, Outlook and more — read and reply from a single unified feed.
    - generic [ref=e43]:
      - img [ref=e45]
      - generic [ref=e59]: Unified search
      - generic [ref=e60]: Find any message across every connected channel in seconds, no matter where it was sent.
    - generic [ref=e62]:
      - img [ref=e64]
      - generic [ref=e70]: AI-powered replies
      - generic [ref=e71]: Let the built-in AI draft replies and summarise long threads so you can focus on what matters.
    - generic [ref=e73]:
      - img [ref=e75]
      - generic [ref=e89]: Free from day one
      - generic [ref=e90]: Every feature unlocked the moment you sign up — no credit card, no hidden fees.
  - generic [ref=e91]:
    - generic "Go to slide 1" [ref=e92] [cursor=pointer]
    - generic "Go to slide 2" [ref=e93] [cursor=pointer]
    - generic "Go to slide 3" [ref=e94] [cursor=pointer]
    - generic "Go to slide 4" [active] [ref=e95] [cursor=pointer]
  - generic [ref=e96]:
    - generic [ref=e97] [cursor=pointer]:
      - generic [ref=e98]: Next
      - generic [ref=e99]: 
    - generic [ref=e100]: By continuing you agree to our Terms and Privacy Policy.
```

# Test source

```ts
  200 |     page,
  201 |   }) => {
  202 |     await page.route(OIDC_DISCOVERY_URL, async (route) => {
  203 |       await new Promise<void>((resolve) => setTimeout(resolve, 500));
  204 |       await route.fulfill({
  205 |         status: 200,
  206 |         contentType: "application/json",
  207 |         body: JSON.stringify(MOCK_DISCOVERY),
  208 |       });
  209 |     });
  210 | 
  211 |     await page.route(`${OIDC_AUTHORIZE_URL}*`, async (route) => {
  212 |       await route.fulfill({
  213 |         status: 200,
  214 |         contentType: "text/html",
  215 |         body: "<html><body>Mock auth page</body></html>",
  216 |       });
  217 |     });
  218 | 
  219 |     await page.getByTestId("signup-dot-3").click();
  220 |     await expect(page.getByTestId("signup-continue-button")).toBeVisible();
  221 | 
  222 |     await page.getByTestId("signup-continue-button").click();
  223 | 
  224 |     await expect(page.getByTestId("signup-continue-button")).toHaveAttribute(
  225 |       "aria-disabled",
  226 |       "true",
  227 |     );
  228 |     await expect(page.getByText("Create my free account")).not.toBeVisible();
  229 |   });
  230 | 
  231 |   test("shows error banner when OIDC discovery endpoint returns a server error", async ({
  232 |     page,
  233 |   }) => {
  234 |     await page.route(OIDC_DISCOVERY_URL, async (route) => {
  235 |       await route.fulfill({
  236 |         status: 500,
  237 |         contentType: "application/json",
  238 |         body: JSON.stringify({ error: "Internal Server Error" }),
  239 |       });
  240 |     });
  241 | 
  242 |     await page.getByTestId("signup-dot-3").click();
  243 |     await expect(page.getByTestId("signup-continue-button")).toBeVisible();
  244 | 
  245 |     await page.getByTestId("signup-continue-button").click();
  246 | 
  247 |     await expect(page.getByTestId("signup-error-banner")).toBeVisible({
  248 |       timeout: 10_000,
  249 |     });
  250 |   });
  251 | 
  252 |   test("error banner clears when the user retries sign-up after a failure", async ({
  253 |     page,
  254 |   }) => {
  255 |     // First click: OIDC discovery fails with 500.
  256 |     // Subsequent calls: discovery succeeds (slowed) so we can observe the
  257 |     // loading state and verify the banner has cleared during the retry.
  258 |     let discoveryCallCount = 0;
  259 |     await page.route(OIDC_DISCOVERY_URL, async (route) => {
  260 |       discoveryCallCount++;
  261 |       if (discoveryCallCount === 1) {
  262 |         await route.fulfill({
  263 |           status: 500,
  264 |           contentType: "application/json",
  265 |           body: JSON.stringify({ error: "Internal Server Error" }),
  266 |         });
  267 |         return;
  268 |       }
  269 |       // Slow the success response so the loading state is observable
  270 |       // before the page navigates away to the mock authorize endpoint.
  271 |       await new Promise<void>((resolve) => setTimeout(resolve, 500));
  272 |       await route.fulfill({
  273 |         status: 200,
  274 |         contentType: "application/json",
  275 |         body: JSON.stringify(MOCK_DISCOVERY),
  276 |       });
  277 |     });
  278 | 
  279 |     await page.route(`${OIDC_AUTHORIZE_URL}*`, async (route) => {
  280 |       await route.fulfill({
  281 |         status: 200,
  282 |         contentType: "text/html",
  283 |         body: "<html><body>Mock auth page</body></html>",
  284 |       });
  285 |     });
  286 | 
  287 |     // Advance to the final slide. We click dot-3 and then dispatch a real
  288 |     // scroll event on the carousel — React Native Web's `onMomentumScrollEnd`
  289 |     // does not always fire from programmatic `scrollTo` in headless Chromium,
  290 |     // so we scroll the underlying div ourselves to ensure `activeIndex`
  291 |     // updates and the CTA renders.
  292 |     await page.getByTestId("signup-dot-3").click();
  293 |     await page.getByTestId("signup-carousel").evaluate((el) => {
  294 |       const scroller = el as HTMLElement;
  295 |       const target = scroller.scrollWidth - scroller.clientWidth;
  296 |       scroller.scrollLeft = target;
  297 |       scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
  298 |       scroller.dispatchEvent(new Event("scrollend", { bubbles: true }));
  299 |     });
> 300 |     await expect(page.getByTestId("signup-continue-button")).toBeVisible({
      |                                                              ^ Error: expect(locator).toBeVisible() failed
  301 |       timeout: 10_000,
  302 |     });
  303 | 
  304 |     // First attempt — failure path
  305 |     await page.getByTestId("signup-continue-button").click();
  306 |     await expect(page.getByTestId("signup-error-banner")).toBeVisible({
  307 |       timeout: 10_000,
  308 |     });
  309 | 
  310 |     // CTA must be re-enabled and visible again so the user can retry
  311 |     await expect(page.getByTestId("signup-continue-button")).toBeVisible();
  312 |     await expect(page.getByTestId("signup-continue-button")).not.toHaveAttribute(
  313 |       "aria-disabled",
  314 |       "true",
  315 |     );
  316 | 
  317 |     // Second attempt — recovery path. Banner should clear immediately
  318 |     // (setSignInError(null) at the start of startAuthFlow).
  319 |     await page.getByTestId("signup-continue-button").click();
  320 | 
  321 |     await expect(page.getByTestId("signup-error-banner")).not.toBeVisible({
  322 |       timeout: 5_000,
  323 |     });
  324 | 
  325 |     // Loading state should re-appear during the retry attempt
  326 |     await expect(page.getByTestId("signup-continue-button")).toHaveAttribute(
  327 |       "aria-disabled",
  328 |       "true",
  329 |     );
  330 |     await expect(page.getByText("Create my free account")).not.toBeVisible();
  331 | 
  332 |     // Sanity: discovery was hit twice (one fail, one retry success)
  333 |     expect(discoveryCallCount).toBeGreaterThanOrEqual(2);
  334 |   });
  335 | 
  336 |   test("shows error banner when token exchange fails after OAuth callback", async ({
  337 |     page,
  338 |   }) => {
  339 |     const TEST_STATE = "e2e-test-oauth-state-token-error";
  340 |     const TEST_CODE = "e2e-test-auth-code-token-error";
  341 | 
  342 |     await page.route("**/api/mobile-auth/token-exchange", async (route) => {
  343 |       await route.fulfill({
  344 |         status: 500,
  345 |         contentType: "application/json",
  346 |         body: JSON.stringify({ error: "Token exchange failed" }),
  347 |       });
  348 |     });
  349 | 
  350 |     await page.evaluate(
  351 |       ({ state, pkceData }) => {
  352 |         sessionStorage.setItem("commshub_oauth_state", state);
  353 |         sessionStorage.setItem(
  354 |           "commshub_pkce_state",
  355 |           JSON.stringify(pkceData),
  356 |         );
  357 |       },
  358 |       {
  359 |         state: TEST_STATE,
  360 |         pkceData: {
  361 |           codeVerifier: "e2e-test-verifier-string",
  362 |           nonce: "e2e-test-nonce-string",
  363 |         },
  364 |       },
  365 |     );
  366 | 
  367 |     await page.goto(`/?code=${TEST_CODE}&state=${TEST_STATE}`);
  368 | 
  369 |     await expect(page).toHaveURL(/\/(login|signup)/, { timeout: 15_000 });
  370 | 
  371 |     await expect(page.getByTestId("login-error-banner")).toBeVisible({
  372 |       timeout: 10_000,
  373 |     });
  374 |   });
  375 | 
  376 |   test("successful OAuth callback signs the user in and lands them on the app", async ({
  377 |     page,
  378 |   }) => {
  379 |     const TEST_STATE = "e2e-test-oauth-state-abcdef123456";
  380 |     const TEST_CODE = "e2e-test-auth-code-abcdef123456";
  381 |     const TEST_TOKEN = "e2e-test-session-token-abcdef123456";
  382 | 
  383 |     await page.route("**/api/mobile-auth/token-exchange", async (route) => {
  384 |       await route.fulfill({
  385 |         status: 200,
  386 |         contentType: "application/json",
  387 |         body: JSON.stringify({ token: TEST_TOKEN }),
  388 |       });
  389 |     });
  390 | 
  391 |     await page.route("**/api/auth/user", async (route) => {
  392 |       await route.fulfill({
  393 |         status: 200,
  394 |         contentType: "application/json",
  395 |         body: JSON.stringify({
  396 |           user: {
  397 |             id: "e2e-test-user-id",
  398 |             email: "e2e@example.com",
  399 |             firstName: "E2E",
  400 |             lastName: "TestUser",
```